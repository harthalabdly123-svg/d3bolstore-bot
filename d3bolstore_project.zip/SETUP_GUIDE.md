# 🚀 دليل إعداد d3bolstore — خطوة بخطوة

---

## الملفات:
- `d3bolstore.jsx` — الموقع
- `d3bolstore_bot.py` — بوت تيليجرام
- `SETUP_GUIDE.md` — هذا الدليل

---

## الخطوة 1: إنشاء مشروع Firebase

1. روح على https://console.firebase.google.com
2. اضغط **Add project** → سمه `d3bolstore`
3. فعّل **Authentication**:
   - اضغط Authentication → Sign-in method → Email/Password → Enable
4. فعّل **Firestore Database**:
   - اضغط Firestore → Create database → Start in test mode
5. جيب الـ Config:
   - Project Settings → Your apps → Add web app
   - انسخ الـ `firebaseConfig` وضعه بالموقع

---

## الخطوة 2: إعداد Firebase Admin للبوت

1. Project Settings → Service Accounts → Generate new private key
2. احفظ الملف باسم `serviceAccountKey.json` بنفس مجلد البوت

---

## الخطوة 3: إنشاء بوت تيليجرام

1. افتح تيليجرام وكلم @BotFather
2. اكتب `/newbot` واتبع التعليمات
3. انسخ الـ Token وضعه في `BOT_TOKEN`
4. جيب الـ ADMIN_ID:
   - كلم @userinfobot على تيليجرام
   - انسخ الـ ID وضعه في `ADMIN_ID`

---

## الخطوة 4: تثبيت وتشغيل البوت

```bash
pip install python-telegram-bot firebase-admin
python d3bolstore_bot.py
```

---

## الخطوة 5: قواعد Firestore

بعد ما الموقع يشتغل، غير Rules في Firestore لـ:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{doc} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.uid;
      allow create: if request.auth != null;
    }
    match /orders/{doc} {
      allow read: if request.auth != null && request.auth.uid == resource.data.uid;
      allow create: if request.auth != null;
      allow update: if false; // فقط البوت يعدل
    }
  }
}
```

---

## كيف يشتغل النظام؟

```
المستخدم يطلب
      ↓
يُحفظ في Firestore بحالة "بانتظار التفعيل"
      ↓
البوت يرسل لك إشعار على تيليجرام
      ↓
أنت تضغط "تفعيل" وترسل الكود
      ↓
Firestore يتحدث → الكود يظهر بداشبورد المستخدم
      ↓
المستخدم يتلقى إشعار على تيليجرامه + يشوف الكود بالموقع
```

---

## أوامر البوت:

| الأمر | الوظيفة |
|-------|---------|
| `/start` | تشغيل البوت |
| `/orders` | قائمة الطلبات النشطة |
| `/usage <id> <used> <total>` | تحديث الصرف |

### مثال تحديث الصرف:
```
/usage abc123xyz 15.5 50
```
هذا يحدث الداشبورد ويظهر: 15.5GB / 50GB مع شريط تقدم

