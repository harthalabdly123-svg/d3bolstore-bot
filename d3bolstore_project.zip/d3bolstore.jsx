import { useState, useEffect } from "react";

// ─── FIREBASE CONFIG ──────────────────────────────────────────────────────────
// ضع هنا بيانات Firebase الخاصة بك
const firebaseConfig = {
  apiKey: "AIzaSyDXojUukJD7ADHgYpxgH1zN9wlk1x5Noxk",
  authDomain: "d3bol-store.firebaseapp.com",
  projectId: "d3bol-store",
  storageBucket: "d3bol-store.firebasestorage.app",
  messagingSenderId: "935028296061",
  appId: "1:935028296061:web:1d85a7896884f85c0b6414"
};

// ─── FIREBASE HELPERS (CDN) ───────────────────────────────────────────────────
let db, auth, fbApp;
async function initFirebase() {
  if (fbApp) return;
  const { initializeApp } = await import("https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js");
  const { getFirestore, collection, addDoc, doc, getDoc, query, where, getDocs, onSnapshot, updateDoc } = await import("https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js");
  const { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged } = await import("https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js");
  fbApp = initializeApp(firebaseConfig);
  db = getFirestore(fbApp);
  auth = getAuth(fbApp);
  window._fb = { db, auth, collection, addDoc, doc, getDoc, query, where, getDocs, onSnapshot, updateDoc, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged };
}

// ─── PLANS DATA ───────────────────────────────────────────────────────────────
const PLANS = [
  {
    id: "netcap", name: "سيرفر نت كاب", icon: "🖥️",
    color: "#00d4ff", glow: "#00d4ff33", border: "#00d4ff44", tag: null,
    prices: [
      { id: "1m", label: "شهر",     months: 1, price: 5000,  save: null },
      { id: "2m", label: "شهرين",  months: 2, price: 7000,  save: null },
      { id: "3m", label: "3 أشهر", months: 3, price: 10000, save: "وفر 33%" },
    ],
    desc: "سرعات عالية والسرعة الداخلية للسيرفر 2.5G. سيرفر قوي للألعاب وسرعة في التصفح.",
    protocols: ["VLESS"],
    features: ["سرعة داخلية 2.5G","سرعات تحميل عالية","قوي للألعاب","Ping منخفض","استقرار عالي","بدون حدود ترافيك","مناسب للستريم"],
    shortFeats: ["سرعة 2.5G","مناسب للألعاب","تصفح سريع"],
  },
  {
    id: "fodo", name: "سيرفر فودو", icon: "📺",
    color: "#ff6b00", glow: "#ff6b0033", border: "#ff6b0044", tag: null,
    prices: [{ id: "1m", label: "شهر", months: 1, price: 7000, save: null }],
    desc: "سيرفر فودو مخصص لمشاهدة الأفلام والمسلسلات العالمية بجودة HD بدون انقطاع.",
    protocols: ["VLESS"],
    features: ["منصة فودو","أفلام عالمية","مسلسلات عالمية","بث بدون انقطاع","جودة HD","بدون حدود ترافيك"],
    shortFeats: ["منصة فودو","أفلام ومسلسلات","جودة HD"],
  },
  {
    id: "cinemabox", name: "سيرفر سينمابوكس", icon: "🎬",
    color: "#a855f7", glow: "#a855f733", border: "#a855f744", tag: null,
    prices: [{ id: "1m", label: "شهر", months: 1, price: 7000, save: null }],
    desc: "سيرفر سينمابوكس للمشاهدة والتحميل. أفلام ومسلسلات عراقية وعالمية بجودة عالية.",
    protocols: ["VLESS"],
    features: ["منصة سينمابوكس","أفلام عراقية","مسلسلات عراقية","بث بدون انقطاع","جودة HD","بدون حدود ترافيك"],
    shortFeats: ["سينمابوكس","أفلام عراقية","جودة HD"],
  },
  {
    id: "combo", name: "سينمابوكس + فودو", icon: "🌟",
    color: "#f59e0b", glow: "#f59e0b33", border: "#f59e0b44", tag: "الأوفر",
    prices: [{ id: "1m", label: "شهر", months: 1, price: 13000, save: null }],
    desc: "اشترك بسينمابوكس وفودو معاً بسعر مميز. أفلام ومسلسلات عراقية وعالمية بمنصتين.",
    protocols: ["VLESS"],
    features: ["سينمابوكس كاملة","فودو كاملة","أفلام عراقية وعالمية","مسلسلات عراقية وعالمية","جودة HD","بدون حدود ترافيك","أوفر من الشراء المنفرد"],
    shortFeats: ["سينمابوكس + فودو","منصتين بسعر واحد","الأوفر"],
  },
];

// ─── THEME ────────────────────────────────────────────────────────────────────
const G = {
  bg:"#07070f", bg2:"#0d0d1a", card:"#111120", card2:"#16162a",
  cyan:"#00d4ff", orange:"#ff6b00", purple:"#a855f7", yellow:"#f59e0b",
  green:"#00e676", red:"#ff4444", text:"#ffffff", text2:"#8888aa",
  border:"rgba(255,255,255,0.07)",
};
const css = {
  app:{ minHeight:"100vh", background:G.bg, color:G.text, fontFamily:"'Cairo',sans-serif", direction:"rtl" },
  nav:{ position:"fixed", top:0, left:0, right:0, zIndex:100, background:"rgba(7,7,15,0.92)", backdropFilter:"blur(20px)", borderBottom:`1px solid ${G.border}`, padding:"14px 20px", display:"flex", alignItems:"center", justifyContent:"space-between" },
  logo:{ fontSize:"1.25rem", fontWeight:900, letterSpacing:1, background:`linear-gradient(135deg,${G.cyan},${G.orange})`, WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" },
  btnP:(c=G.orange)=>({ background:c, color:(c==="#f59e0b"||c==="#00d4ff")?"#000":"#fff", border:"none", padding:"12px 24px", borderRadius:12, fontFamily:"'Cairo',sans-serif", fontWeight:700, fontSize:"0.95rem", cursor:"pointer", transition:"all 0.2s", boxShadow:`0 4px 20px ${c}44` }),
  btnO:(c=G.cyan)=>({ background:"transparent", color:c, border:`1.5px solid ${c}`, padding:"11px 22px", borderRadius:12, fontFamily:"'Cairo',sans-serif", fontWeight:700, fontSize:"0.9rem", cursor:"pointer" }),
  card:(gc="transparent",active=false)=>({ background:G.card, border:`1.5px solid ${active?gc:G.border}`, borderRadius:20, boxShadow:active?`0 0 30px ${gc}`:"none", transition:"all 0.3s" }),
  input:{ width:"100%", background:G.card2, border:`1px solid ${G.border}`, borderRadius:12, color:G.text, fontFamily:"'Cairo',sans-serif", fontSize:"0.95rem", padding:"13px 16px", outline:"none", boxSizing:"border-box" },
  lbl:{ fontSize:"0.85rem", color:G.text2, marginBottom:6, display:"block", fontWeight:600 },
};

// ─── HOME PAGE ────────────────────────────────────────────────────────────────
function HomePage({ onNav, user }) {
  return (
    <div style={{paddingTop:70}}>
      <div style={{minHeight:"90vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"40px 20px",textAlign:"center",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",top:"20%",left:"50%",transform:"translateX(-50%)",width:500,height:500,background:"radial-gradient(circle,#00d4ff0d 0%,transparent 65%)",pointerEvents:"none"}}/>
        <div style={{display:"inline-flex",alignItems:"center",gap:8,background:"#00d4ff12",border:"1px solid #00d4ff33",color:G.cyan,padding:"7px 18px",borderRadius:99,fontSize:"0.82rem",fontWeight:700,marginBottom:28}}>⚡ أقوى VPN في العراق</div>
        <h1 style={{fontSize:"clamp(2rem,8vw,3.2rem)",fontWeight:900,lineHeight:1.2,marginBottom:20,maxWidth:600}}>
          انترنت <span style={{background:`linear-gradient(135deg,${G.cyan},${G.purple})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>بلا حدود</span>
          <br/>مع <span style={{color:G.orange}}>دعبول ستور</span>
        </h1>
        <p style={{color:G.text2,fontSize:"1rem",lineHeight:1.8,maxWidth:360,marginBottom:36}}>اشتراكات VPN سريعة وآمنة بأفضل الأسعار. سيرفرات متنوعة لكل احتياجاتك.</p>
        <div style={{display:"flex",gap:12,flexWrap:"wrap",justifyContent:"center",marginBottom:50}}>
          <button style={css.btnP(G.orange)} onClick={()=>onNav("plans")}>تصفح السيرفرات 📦</button>
          {!user && <button style={css.btnO(G.cyan)} onClick={()=>onNav("register")}>إنشاء حساب مجاني</button>}
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16,width:"100%",maxWidth:400}}>
          {[["500+","مشترك نشط"],["99.9%","وقت التشغيل"],["24/7","دعم فني"]].map(([n,l])=>(
            <div key={l} style={{...css.card(),padding:"16px 10px",textAlign:"center"}}>
              <div style={{fontSize:"1.4rem",fontWeight:900,color:G.cyan}}>{n}</div>
              <div style={{fontSize:"0.75rem",color:G.text2,marginTop:4}}>{l}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{padding:"0 20px 60px"}}>
        <h2 style={{textAlign:"center",fontSize:"1.6rem",fontWeight:900,marginBottom:32}}>ليش دعبول ستور؟</h2>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,maxWidth:500,margin:"0 auto"}}>
          {[["⚡","تسليم فوري","فور تأكيد الدفع"],["🛡️","حماية كاملة","تشفير VLESS"],["🌍","4 سيرفرات","نت كاب، فودو، سينمابوكس، كومبو"],["💬","دعم 24/7","تيليجرام وواتساب"],["💰","أسعار مميزة","تبدأ من 5,000 د.ع"],["🔄","تجديد سهل","من داشبورد حسابك"]].map(([icon,title,sub])=>(
            <div key={title} style={{...css.card(),padding:"18px 14px"}}>
              <div style={{width:42,height:42,borderRadius:12,background:"#00d4ff15",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.2rem",marginBottom:10}}>{icon}</div>
              <div style={{fontWeight:700,fontSize:"0.95rem"}}>{title}</div>
              <div style={{color:G.text2,fontSize:"0.78rem",marginTop:4}}>{sub}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── PLANS PAGE ───────────────────────────────────────────────────────────────
function PlansPage({ onOrder, user, onNav }) {
  const [detail, setDetail] = useState(null);
  const [selDur, setSelDur] = useState({});

  return (
    <div style={{padding:"80px 20px 80px"}}>
      <div style={{textAlign:"center",marginBottom:36}}>
        <div style={{display:"inline-block",background:"#ff6b0015",border:"1px solid #ff6b0033",color:G.orange,padding:"6px 16px",borderRadius:99,fontSize:"0.82rem",fontWeight:700,marginBottom:16}}>سيرفراتنا</div>
        <h2 style={{fontSize:"1.8rem",fontWeight:900,marginBottom:8}}>اختر سيرفرك</h2>
        <p style={{color:G.text2,fontSize:"0.9rem"}}>كل سيرفر مخصص لاحتياجات مختلفة</p>
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:18,maxWidth:500,margin:"0 auto"}}>
        {PLANS.map(plan=>{
          const curId=selDur[plan.id]||plan.prices[0].id;
          const curPrice=plan.prices.find(p=>p.id===curId)||plan.prices[0];
          return (
            <div key={plan.id} style={{...css.card(plan.border,false),overflow:"hidden",position:"relative"}}>
              <div style={{height:4,background:`linear-gradient(90deg,${plan.color},transparent)`}}/>
              {plan.tag&&<div style={{position:"absolute",top:16,left:16}}><span style={{background:G.yellow,color:"#000",fontSize:"0.72rem",fontWeight:800,padding:"4px 12px",borderRadius:99}}>{plan.tag}</span></div>}
              <div style={{padding:"20px 18px"}}>
                <div style={{display:"flex",flexDirection:"column",alignItems:"center",marginBottom:18,textAlign:"center"}}>
                  <div style={{width:64,height:64,borderRadius:"50%",background:`${plan.color}18`,border:`1px solid ${plan.color}33`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.8rem",marginBottom:12,boxShadow:`0 0 20px ${plan.glow}`}}>{plan.icon}</div>
                  <h3 style={{fontWeight:900,fontSize:"1.2rem",marginBottom:4}}>{plan.name}</h3>
                  <div style={{color:G.text2,fontSize:"0.82rem",marginBottom:12}}>سيرفر مخصص وسريع</div>
                  <div style={{display:"flex",alignItems:"baseline",gap:6}}>
                    <span style={{fontSize:"2.2rem",fontWeight:900,color:plan.color}}>{curPrice.price.toLocaleString()}</span>
                    <span style={{fontSize:"0.85rem",color:G.text2}}>د.ع / {curPrice.label}</span>
                  </div>
                </div>
                {plan.prices.length>1&&(
                  <div style={{display:"flex",gap:8,marginBottom:16}}>
                    {plan.prices.map(p=>(
                      <button key={p.id} onClick={()=>setSelDur(s=>({...s,[plan.id]:p.id}))} style={{flex:1,padding:"9px 4px",borderRadius:10,border:`1.5px solid ${curId===p.id?plan.color:G.border}`,background:curId===p.id?`${plan.color}18`:"transparent",color:curId===p.id?plan.color:G.text2,cursor:"pointer",fontFamily:"'Cairo',sans-serif",fontWeight:700,fontSize:"0.8rem",transition:"all 0.2s"}}>
                        {p.label}
                        {p.save&&<div style={{fontSize:"0.65rem",color:G.green,marginTop:2}}>{p.save}</div>}
                      </button>
                    ))}
                  </div>
                )}
                <div style={{marginBottom:16}}>
                  {plan.shortFeats.map(f=>(
                    <div key={f} style={{display:"flex",alignItems:"center",justifyContent:"flex-end",gap:10,padding:"9px 12px",background:G.card2,borderRadius:10,marginBottom:8,fontSize:"0.9rem"}}>
                      <span style={{color:G.text}}>{f}</span>
                      <span style={{color:G.green,background:"#00e67622",width:24,height:24,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:"0.85rem"}}>✓</span>
                    </div>
                  ))}
                </div>
                <div style={{display:"flex",gap:8,justifyContent:"center",marginBottom:16}}>
                  {plan.protocols.map(p=><span key={p} style={{background:"#00e67618",border:"1px solid #00e67633",color:G.green,fontSize:"0.82rem",fontWeight:700,padding:"5px 14px",borderRadius:99}}>{p}</span>)}
                </div>
                <div style={{display:"flex",gap:10}}>
                  <button style={{...css.btnO(plan.color),flex:1,display:"flex",alignItems:"center",justifyContent:"center",gap:6}} onClick={()=>setDetail(plan)}>← تفاصيل</button>
                  <button style={{...css.btnP(plan.color),flex:1.4}} onClick={()=>{if(!user){onNav("login");return;}onOrder({plan,price:curPrice});}}>🛒 اشترك الآن</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      {detail&&(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.88)",zIndex:999,overflowY:"auto"}} onClick={e=>e.target===e.currentTarget&&setDetail(null)}>
          <div style={{minHeight:"100vh",display:"flex",alignItems:"flex-start",justifyContent:"center",padding:"20px 16px 40px"}}>
            <div style={{background:G.card,borderRadius:24,width:"100%",maxWidth:480,border:`1px solid ${detail.border}`,overflow:"hidden"}}>
              <div style={{height:4,background:`linear-gradient(90deg,${detail.color},transparent)`}}/>
              <div style={{padding:"22px 20px"}}>
                <button onClick={()=>setDetail(null)} style={{background:G.card2,border:`1px solid ${G.border}`,color:G.text,width:34,height:34,borderRadius:"50%",fontSize:"1rem",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",marginBottom:20}}>✕</button>
                <div style={{textAlign:"center",marginBottom:20}}>
                  <div style={{width:72,height:72,borderRadius:"50%",background:`${detail.color}18`,border:`1px solid ${detail.color}44`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"2rem",margin:"0 auto 14px"}}>{detail.icon}</div>
                  <h2 style={{fontWeight:900,fontSize:"1.4rem",marginBottom:6}}>{detail.name}</h2>
                  <div style={{fontSize:"1.6rem",fontWeight:900,color:detail.color}}>{detail.prices[0].price.toLocaleString()} <span style={{fontSize:"0.8rem",color:G.text2}}>د.ع / شهر</span></div>
                </div>
                <div style={{background:G.card2,border:`1px solid ${detail.border}`,borderRadius:14,padding:"14px 16px",marginBottom:18,fontSize:"0.88rem",color:G.text2,lineHeight:1.8}}>{detail.desc}</div>
                <div style={{marginBottom:18}}>
                  {detail.features.map(f=>(
                    <div key={f} style={{display:"flex",alignItems:"center",justifyContent:"flex-end",gap:10,padding:"10px 12px",background:G.card2,borderRadius:10,marginBottom:8,fontSize:"0.9rem"}}>
                      <span>{f}</span>
                      <span style={{color:G.green,background:"#00e67622",width:26,height:26,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>✓</span>
                    </div>
                  ))}
                </div>
                <button style={{...css.btnP(detail.color),width:"100%",fontSize:"1rem",padding:"14px"}} onClick={()=>{setDetail(null);if(!user){onNav("login");return;}onOrder({plan:detail,price:detail.prices[0]});}}>
                  🛒 اشترك الآن — {detail.prices[0].price.toLocaleString()} د.ع
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── AUTH PAGE ────────────────────────────────────────────────────────────────
function AuthPage({ mode, onAuth, onSwitch }) {
  const [form,setForm]=useState({name:"",email:"",password:"",telegram:""});
  const [loading,setLoading]=useState(false);
  const [err,setErr]=useState("");
  const isLogin=mode==="login";

  const handle=async()=>{
    setErr("");
    if(!form.email||!form.password){setErr("يرجى تعبئة الحقول المطلوبة");return;}
    if(!isLogin&&!form.name){setErr("يرجى إدخال الاسم");return;}
    setLoading(true);
    try {
      await initFirebase();
      const {auth,createUserWithEmailAndPassword,signInWithEmailAndPassword,db,collection,addDoc}=window._fb;
      if(isLogin){
        const cred=await signInWithEmailAndPassword(auth,form.email,form.password);
        onAuth({uid:cred.user.uid,name:form.name||form.email.split("@")[0],email:form.email,telegram:form.telegram});
      } else {
        const cred=await createUserWithEmailAndPassword(auth,form.email,form.password);
        await addDoc(collection(db,"users"),{uid:cred.user.uid,name:form.name,email:form.email,telegram:form.telegram,createdAt:new Date().toISOString()});
        onAuth({uid:cred.user.uid,name:form.name,email:form.email,telegram:form.telegram});
      }
    } catch(e) {
      const msgs={"auth/email-already-in-use":"الإيميل مستخدم مسبقاً","auth/wrong-password":"كلمة المرور غلط","auth/user-not-found":"حساب غير موجود","auth/weak-password":"كلمة المرور ضعيفة جداً"};
      setErr(msgs[e.code]||"حصل خطأ، حاول مرة ثانية");
    }
    setLoading(false);
  };

  return (
    <div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",padding:"80px 20px 40px"}}>
      <div style={{width:"100%",maxWidth:420}}>
        <div style={{textAlign:"center",marginBottom:32}}>
          <div style={{...css.logo,fontSize:"1.8rem",marginBottom:8}}>دعبول ستور</div>
          <div style={{color:G.text2,fontSize:"0.9rem"}}>{isLogin?"أهلاً بعودتك 👋":"إنشاء حساب جديد 🚀"}</div>
        </div>
        <div style={{...css.card(),padding:"28px 22px"}}>
          {!isLogin&&<div style={{marginBottom:18}}><label style={css.lbl}>الاسم الكامل *</label><input style={css.input} placeholder="اسمك هنا" value={form.name} onChange={e=>setForm(s=>({...s,name:e.target.value}))}/></div>}
          <div style={{marginBottom:18}}><label style={css.lbl}>البريد الإلكتروني *</label><input style={css.input} type="email" placeholder="email@example.com" value={form.email} onChange={e=>setForm(s=>({...s,email:e.target.value}))}/></div>
          {!isLogin&&<div style={{marginBottom:18}}><label style={css.lbl}>معرف تيليجرام</label><input style={css.input} placeholder="@username" value={form.telegram} onChange={e=>setForm(s=>({...s,telegram:e.target.value}))}/></div>}
          <div style={{marginBottom:22}}><label style={css.lbl}>كلمة المرور *</label><input style={css.input} type="password" placeholder="••••••••" value={form.password} onChange={e=>setForm(s=>({...s,password:e.target.value}))}/></div>
          {err&&<div style={{background:"#ff444418",border:"1px solid #ff444433",color:G.red,padding:"10px 14px",borderRadius:10,fontSize:"0.85rem",marginBottom:16}}>{err}</div>}
          <button style={{...css.btnP(G.orange),width:"100%",fontSize:"1rem",padding:"14px"}} onClick={handle} disabled={loading}>
            {loading?"⏳ جاري...":isLogin?"دخول":"إنشاء الحساب"}
          </button>
          <div style={{textAlign:"center",marginTop:20,fontSize:"0.88rem",color:G.text2}}>
            {isLogin?"ما عندك حساب؟ ":"عندك حساب؟ "}
            <span style={{color:G.cyan,cursor:"pointer",fontWeight:700}} onClick={onSwitch}>{isLogin?"سجل الآن":"ادخل"}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard({ user, onLogout, onNav }) {
  const [tab,setTab]=useState("overview");
  const [orders,setOrders]=useState([]);
  const [loading,setLoading]=useState(true);

  useEffect(()=>{
    if(!user?.uid) return;
    let unsub;
    (async()=>{
      await initFirebase();
      const {db,collection,query,where,onSnapshot}=window._fb;
      const q=query(collection(db,"orders"),where("uid","==",user.uid));
      unsub=onSnapshot(q,snap=>{
        const data=snap.docs.map(d=>({id:d.id,...d.data()}));
        data.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
        setOrders(data);
        setLoading(false);
      });
    })();
    return()=>unsub&&unsub();
  },[user]);

  const active=orders.filter(o=>o.status==="نشط");

  // حساب نسبة الصرف
  const calcUsage=(order)=>{
    if(!order.usedGB||!order.totalGB) return null;
    return Math.round((order.usedGB/order.totalGB)*100);
  };

  return (
    <div style={{paddingTop:70,minHeight:"100vh"}}>
      <div style={{padding:"24px 20px 0",background:`linear-gradient(180deg,${G.bg2} 0%,${G.bg} 100%)`,borderBottom:`1px solid ${G.border}`,marginBottom:24}}>
        <div style={{maxWidth:600,margin:"0 auto"}}>
          <div style={{display:"flex",alignItems:"center",gap:14,marginBottom:20}}>
            <div style={{width:52,height:52,borderRadius:"50%",background:`linear-gradient(135deg,${G.cyan},${G.purple})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.4rem",fontWeight:900,color:"#000",flexShrink:0}}>
              {user.name[0].toUpperCase()}
            </div>
            <div>
              <div style={{fontWeight:900,fontSize:"1.1rem"}}>أهلاً، {user.name} 👋</div>
              <div style={{color:G.text2,fontSize:"0.82rem"}}>{user.email}</div>
            </div>
          </div>
          <div style={{display:"flex",borderBottom:`1px solid ${G.border}`}}>
            {[["overview","🏠","نظرة عامة"],["orders","📦","طلباتي"],["profile","👤","الحساب"]].map(([id,icon,label])=>(
              <button key={id} onClick={()=>setTab(id)} style={{flex:1,background:"none",border:"none",borderBottom:`2px solid ${tab===id?G.orange:"transparent"}`,color:tab===id?G.orange:G.text2,padding:"10px 4px",fontFamily:"'Cairo',sans-serif",fontWeight:700,fontSize:"0.82rem",cursor:"pointer"}}>
                {icon} {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{padding:"0 20px 80px",maxWidth:600,margin:"0 auto"}}>
        {loading&&<div style={{textAlign:"center",padding:40,color:G.text2}}>⏳ جاري التحميل...</div>}

        {!loading&&tab==="overview"&&(
          <div>
            {active.length>0?(
              active.map(order=>(
                <div key={order.id} style={{...css.card(G.cyan+"44",true),padding:"20px 18px",marginBottom:16}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
                    <span style={{background:"#00e67622",color:G.green,border:"1px solid #00e67644",fontSize:"0.78rem",fontWeight:700,padding:"4px 12px",borderRadius:99}}>✅ نشط</span>
                    <div style={{fontWeight:900,fontSize:"1rem"}}>{order.plan}</div>
                  </div>

                  {/* الكود */}
                  {order.vpnCode&&(
                    <div style={{background:G.card2,borderRadius:12,padding:"12px 14px",marginBottom:14}}>
                      <div style={{color:G.text2,fontSize:"0.78rem",marginBottom:6}}>كود VPN الخاص بك</div>
                      <div style={{fontFamily:"monospace",fontSize:"0.8rem",color:G.cyan,wordBreak:"break-all",lineHeight:1.6}}>{order.vpnCode}</div>
                      <button onClick={()=>navigator.clipboard.writeText(order.vpnCode)} style={{...css.btnO(G.cyan),padding:"6px 14px",fontSize:"0.78rem",marginTop:8}}>
                        📋 نسخ الكود
                      </button>
                    </div>
                  )}
                  {!order.vpnCode&&(
                    <div style={{background:"#f59e0b15",border:"1px solid #f59e0b33",borderRadius:12,padding:"12px 14px",marginBottom:14,fontSize:"0.85rem",color:"#f59e0b"}}>
                      ⏳ بانتظار تفعيل الكود من الأدمن
                    </div>
                  )}

                  {/* تاريخ الانتهاء */}
                  <div style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:`1px solid ${G.border}`,fontSize:"0.85rem"}}>
                    <span style={{color:G.green,fontWeight:600}}>{order.expires||"—"}</span>
                    <span style={{color:G.text2}}>ينتهي في</span>
                  </div>

                  {/* الصرف / الكيكات */}
                  {order.usedGB!=null&&order.totalGB!=null&&(()=>{
                    const pct=calcUsage(order);
                    const barColor=pct>80?G.red:pct>50?"#f59e0b":G.green;
                    return (
                      <div style={{marginTop:14}}>
                        <div style={{display:"flex",justifyContent:"space-between",marginBottom:8,fontSize:"0.85rem"}}>
                          <span style={{color:barColor,fontWeight:700}}>{order.usedGB} GB / {order.totalGB} GB</span>
                          <span style={{color:G.text2}}>الصرف</span>
                        </div>
                        <div style={{background:G.card2,borderRadius:99,height:8,overflow:"hidden"}}>
                          <div style={{width:`${pct}%`,height:"100%",background:`linear-gradient(90deg,${barColor},${barColor}aa)`,borderRadius:99,transition:"width 0.5s ease"}}/>
                        </div>
                        <div style={{display:"flex",justifyContent:"space-between",marginTop:6,fontSize:"0.75rem",color:G.text2}}>
                          <span>{100-pct}% متبقي</span>
                          <span>{pct}% مستخدم</span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              ))
            ):(
              <div style={{...css.card(),padding:"30px 20px",textAlign:"center",marginBottom:20}}>
                <div style={{fontSize:"2.5rem",marginBottom:12}}>📦</div>
                <div style={{fontWeight:700,marginBottom:8}}>ما عندك اشتراك نشط</div>
                <div style={{color:G.text2,fontSize:"0.85rem",marginBottom:18}}>اشترك الآن وابدأ تصفح بلا حدود</div>
                <button style={css.btnP(G.orange)} onClick={()=>onNav("plans")}>تصفح السيرفرات</button>
              </div>
            )}
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,marginBottom:20}}>
              <div style={{...css.card(),padding:"16px"}}>
                <div style={{color:G.text2,fontSize:"0.78rem",marginBottom:6}}>إجمالي الطلبات</div>
                <div style={{fontSize:"1.8rem",fontWeight:900,color:G.orange}}>{orders.length}</div>
              </div>
              <div style={{...css.card(),padding:"16px"}}>
                <div style={{color:G.text2,fontSize:"0.78rem",marginBottom:6}}>إجمالي المدفوع</div>
                <div style={{fontSize:"1.4rem",fontWeight:900,color:G.cyan}}>{orders.reduce((s,o)=>s+(o.price||0),0).toLocaleString()}<span style={{fontSize:"0.7rem",color:G.text2}}> د.ع</span></div>
              </div>
            </div>
            <button style={{...css.btnO(G.red),width:"100%"}} onClick={onLogout}>تسجيل الخروج</button>
          </div>
        )}

        {!loading&&tab==="orders"&&(
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
              <h3 style={{fontWeight:900,fontSize:"1.1rem"}}>طلباتي ({orders.length})</h3>
              <button style={css.btnP(G.orange)} onClick={()=>onNav("plans")}>+ جديد</button>
            </div>
            {orders.length===0&&<div style={{...css.card(),padding:"30px",textAlign:"center",color:G.text2}}>ما عندك طلبات بعد</div>}
            {orders.map(order=>(
              <div key={order.id} style={{...css.card(),padding:"18px",marginBottom:14}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
                  <span style={{background:order.status==="نشط"?"#00e67622":"#ff444422",color:order.status==="نشط"?G.green:G.red,border:`1px solid ${order.status==="نشط"?"#00e67644":"#ff444444"}`,fontSize:"0.78rem",fontWeight:700,padding:"4px 12px",borderRadius:99}}>{order.status||"بانتظار التفعيل"}</span>
                  <div style={{fontWeight:900,fontSize:"1rem"}}>{order.plan}</div>
                </div>
                {[["رقم الطلب",order.orderId||order.id,G.cyan],["المدة",order.duration,G.text],["السعر",`${(order.price||0).toLocaleString()} د.ع`,G.orange],["تاريخ الطلب",order.date,G.text],["تاريخ الانتهاء",order.expires||"بانتظار التفعيل",order.status==="نشط"?G.green:G.text2]].map(([k,v,c])=>(
                  <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${G.border}`,fontSize:"0.85rem"}}>
                    <span style={{color:c,fontWeight:600}}>{v}</span>
                    <span style={{color:G.text2}}>{k}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
        )}

        {tab==="profile"&&(
          <div>
            <div style={{...css.card(),padding:"22px 18px",marginBottom:16}}>
              <h3 style={{fontWeight:900,marginBottom:20}}>معلومات الحساب</h3>
              {[["الاسم",user.name],["البريد",user.email],["تيليجرام",user.telegram||"غير محدد"]].map(([k,v])=>(
                <div key={k} style={{marginBottom:16}}>
                  <label style={css.lbl}>{k}</label>
                  <div style={{...css.input,opacity:0.7,cursor:"not-allowed"}}>{v}</div>
                </div>
              ))}
            </div>
            <button style={{...css.btnO(G.red),width:"100%"}} onClick={onLogout}>🚪 تسجيل الخروج</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ORDER MODAL ──────────────────────────────────────────────────────────────
function OrderModal({ order, user, onConfirm, onClose }) {
  const [method,setMethod]=useState("zain");
  const [loading,setLoading]=useState(false);
  const [done,setDone]=useState(false);

  const confirm=async()=>{
    setLoading(true);
    try {
      await initFirebase();
      const {db,collection,addDoc}=window._fb;
      const orderId="ORD-"+Date.now();
      const orderData={
        uid:user.uid,
        orderId,
        plan:order.plan.name,
        planId:order.plan.id,
        duration:order.price.label,
        months:order.price.months,
        price:order.price.price,
        paymentMethod:method,
        status:"بانتظار التفعيل",
        vpnCode:null,
        usedGB:null,
        totalGB:null,
        expires:null,
        date:new Date().toISOString().split("T")[0],
        createdAt:new Date().toISOString(),
        userName:user.name,
        userEmail:user.email,
        userTelegram:user.telegram||"غير محدد",
      };
      await addDoc(collection(db,"orders"),orderData);
      setDone(true);
      setTimeout(()=>{onConfirm();},2000);
    } catch(e) {
      alert("حصل خطأ، حاول مرة ثانية");
    }
    setLoading(false);
  };

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",zIndex:999,display:"flex",alignItems:"flex-end"}} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:G.card,width:"100%",borderRadius:"24px 24px 0 0",padding:"24px 20px 40px",maxHeight:"90vh",overflowY:"auto",border:`1px solid ${G.border}`,borderBottom:"none"}}>
        {done?(
          <div style={{textAlign:"center",padding:"30px 0"}}>
            <div style={{fontSize:"3.5rem",marginBottom:16}}>🎉</div>
            <div style={{fontSize:"1.3rem",fontWeight:900,color:G.green,marginBottom:8}}>تم إرسال الطلب!</div>
            <div style={{color:G.text2,lineHeight:1.8}}>سيتواصل معك فريقنا على تيليجرام<br/>وسيظهر الكود بداشبوردك فور التفعيل</div>
          </div>
        ):(
          <>
            <div style={{width:40,height:4,background:G.border,borderRadius:2,margin:"0 auto 20px"}}/>
            <h3 style={{fontWeight:900,fontSize:"1.2rem",marginBottom:4}}>تأكيد الطلب</h3>
            <div style={{color:G.text2,fontSize:"0.85rem",marginBottom:20}}>راجع تفاصيل طلبك</div>
            <div style={{...css.card(order.plan.border,true),padding:"16px",marginBottom:20}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                <span style={{fontWeight:900,fontSize:"1.1rem",color:order.plan.color}}>{order.plan.icon} {order.plan.name}</span>
                <span style={{fontWeight:900,fontSize:"1.1rem"}}>{order.price.price.toLocaleString()} د.ع</span>
              </div>
              <div style={{color:G.text2,fontSize:"0.85rem"}}>المدة: {order.price.label}</div>
            </div>
            <div style={{marginBottom:20}}>
              <label style={{...css.lbl,marginBottom:12}}>طريقة الدفع</label>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["zain","زين كاش"],["asia","آسيا حوالة"],["tasdid","تسديد"],["manual","حوالة يدوية"]].map(([id,label])=>(
                  <button key={id} onClick={()=>setMethod(id)} style={{padding:"12px",borderRadius:12,border:`1.5px solid ${method===id?G.orange:G.border}`,background:method===id?"#ff6b0018":"transparent",color:method===id?G.orange:G.text2,cursor:"pointer",fontFamily:"'Cairo',sans-serif",fontWeight:700,fontSize:"0.88rem"}}>{label}</button>
                ))}
              </div>
            </div>
            <div style={{background:"#00d4ff0d",border:"1px solid #00d4ff22",borderRadius:12,padding:"12px 14px",marginBottom:20,fontSize:"0.83rem",color:G.text2,lineHeight:1.7}}>
              💡 بعد التأكيد سيوصل الطلب للأدمن على تيليجرام وسيتواصل معك لإتمام الدفع. الكود يظهر بداشبوردك فور التفعيل.
            </div>
            <button style={{...css.btnP(G.orange),width:"100%",fontSize:"1rem",padding:"14px"}} onClick={confirm} disabled={loading}>
              {loading?"⏳ جاري الإرسال...":"✅ تأكيد الطلب"}
            </button>
            <button style={{background:"transparent",color:G.text2,border:`1px solid ${G.border}`,padding:"10px 18px",borderRadius:10,fontFamily:"'Cairo',sans-serif",fontWeight:600,fontSize:"0.85rem",cursor:"pointer",width:"100%",marginTop:10}} onClick={onClose}>إلغاء</button>
          </>
        )}
      </div>
    </div>
  );
}

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [page,setPage]=useState("home");
  const [user,setUser]=useState(null);
  const [pending,setPending]=useState(null);
  const [menu,setMenu]=useState(false);
  const [authLoading,setAuthLoading]=useState(true);

  useEffect(()=>{
    const l=document.createElement("link");
    l.href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap";
    l.rel="stylesheet";
    document.head.appendChild(l);

    // تحقق من الجلسة
    (async()=>{
      try {
        await initFirebase();
        const {auth,onAuthStateChanged,db,collection,query,where,getDocs}=window._fb;
        onAuthStateChanged(auth,async fireUser=>{
          if(fireUser){
            // جلب بيانات المستخدم
            const q=query(collection(db,"users"),where("uid","==",fireUser.uid));
            const snap=await getDocs(q);
            if(!snap.empty){
              const data=snap.docs[0].data();
              setUser({uid:fireUser.uid,name:data.name,email:data.email,telegram:data.telegram});
            } else {
              setUser({uid:fireUser.uid,name:fireUser.email.split("@")[0],email:fireUser.email,telegram:""});
            }
          } else {
            setUser(null);
          }
          setAuthLoading(false);
        });
      } catch(e){ setAuthLoading(false); }
    })();
  },[]);

  const handleLogout=async()=>{
    await initFirebase();
    await window._fb.signOut(window._fb.auth);
    setUser(null);
    setPage("home");
  };

  const navItems=[
    {id:"home",label:"الرئيسية"},
    {id:"plans",label:"السيرفرات"},
    ...(user?[{id:"dashboard",label:"حسابي"}]:[{id:"login",label:"دخول"},{id:"register",label:"إنشاء حساب"}]),
  ];

  if(authLoading) return (
    <div style={{...css.app,display:"flex",alignItems:"center",justifyContent:"center",minHeight:"100vh"}}>
      <div style={{textAlign:"center"}}>
        <div style={{...css.logo,fontSize:"2rem",marginBottom:16}}>دعبول ستور</div>
        <div style={{color:G.text2}}>⏳ جاري التحميل...</div>
      </div>
    </div>
  );

  return (
    <div style={css.app}>
      <style>{`*{margin:0;padding:0;box-sizing:border-box}body{background:#07070f}input::placeholder{color:#555570}::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:#0d0d1a}::-webkit-scrollbar-thumb{background:#333350;border-radius:2px}`}</style>

      <nav style={css.nav}>
        <button style={{background:"none",border:"none",cursor:"pointer",padding:4}} onClick={()=>setMenu(m=>!m)}>
          <div style={{display:"flex",flexDirection:"column",gap:5}}>{[0,1,2].map(i=><span key={i} style={{display:"block",width:22,height:2,background:G.text,borderRadius:2}}/>)}</div>
        </button>
        <div style={{...css.logo,cursor:"pointer"}} onClick={()=>setPage("home")}>دعبول ستور</div>
        {user?(
          <div style={{width:36,height:36,borderRadius:"50%",background:`linear-gradient(135deg,${G.cyan},${G.orange})`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,color:"#000",cursor:"pointer",fontSize:"0.9rem"}} onClick={()=>setPage("dashboard")}>
            {user.name[0].toUpperCase()}
          </div>
        ):(
          <button style={{...css.btnP(G.orange),padding:"8px 18px",fontSize:"0.85rem"}} onClick={()=>setPage("login")}>دخول</button>
        )}
      </nav>

      {menu&&(
        <div style={{position:"fixed",inset:0,zIndex:200}}>
          <div style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.7)"}} onClick={()=>setMenu(false)}/>
          <div style={{position:"absolute",top:0,right:0,bottom:0,width:"72%",background:G.bg2,borderLeft:`1px solid ${G.border}`,padding:"70px 24px 30px",display:"flex",flexDirection:"column"}}>
            <button style={{position:"absolute",top:18,right:18,background:"none",border:"none",color:G.text,fontSize:"1.4rem",cursor:"pointer"}} onClick={()=>setMenu(false)}>✕</button>
            <div style={{...css.logo,fontSize:"1.1rem",marginBottom:32}}>دعبول ستور</div>
            {navItems.map(n=>(
              <button key={n.id} onClick={()=>{setPage(n.id);setMenu(false);}} style={{background:"none",border:"none",borderBottom:`1px solid ${G.border}`,color:page===n.id?G.orange:G.text,padding:"16px 0",fontFamily:"'Cairo',sans-serif",fontWeight:700,fontSize:"1.1rem",cursor:"pointer",textAlign:"right"}}>{n.label}</button>
            ))}
          </div>
        </div>
      )}

      {page==="home"&&<HomePage onNav={setPage} user={user}/>}
      {page==="plans"&&<PlansPage onOrder={setPending} user={user} onNav={setPage}/>}
      {(page==="login"||page==="register")&&<AuthPage mode={page} onAuth={u=>{setUser(u);setPage("dashboard");}} onSwitch={()=>setPage(page==="login"?"register":"login")}/>}
      {page==="dashboard"&&user&&<Dashboard user={user} onLogout={handleLogout} onNav={setPage}/>}

      {pending&&<OrderModal order={pending} user={user} onConfirm={()=>{setPending(null);setPage("dashboard");}} onClose={()=>setPending(null)}/>}

      {user&&(
        <div style={{position:"fixed",bottom:0,left:0,right:0,background:"rgba(13,13,26,0.95)",backdropFilter:"blur(20px)",borderTop:`1px solid ${G.border}`,display:"flex",padding:"8px 0 12px",zIndex:90}}>
          {[["home","🏠","الرئيسية"],["plans","📦","السيرفرات"],["dashboard","👤","حسابي"]].map(([id,icon,label])=>(
            <button key={id} onClick={()=>setPage(id)} style={{flex:1,background:"none",border:"none",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:4,color:page===id?G.orange:G.text2,fontFamily:"'Cairo',sans-serif",fontWeight:600,fontSize:"0.72rem"}}>
              <span style={{fontSize:"1.2rem"}}>{icon}</span>{label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
