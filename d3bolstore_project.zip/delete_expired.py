# ═══════════════════════════════════════════════════════
#  d3bolstore — حذف الكلايانتات المنتهية من 3x-ui
#  شغّله على السيرفر: python3 delete_expired.py
#  أو اجعله يشتغل تلقائياً كل يوم عبر cron
# ═══════════════════════════════════════════════════════

import requests
import urllib3
import json
from datetime import datetime

urllib3.disable_warnings()

# ─── إعدادات ─────────────────────────────────────────
BASE_URL  = "https://109.199.102.153:2097/jT7j3ottPNQB983u7Q"
USERNAME  = "admin"
PASSWORD  = "admin1"
# ─────────────────────────────────────────────────────

session = requests.Session()

def login():
    r = session.post(f"{BASE_URL}/login",
        json={"username": USERNAME, "password": PASSWORD},
        verify=False, timeout=10)
    if r.ok and r.json().get("success"):
        print("✅ تم تسجيل الدخول")
        return True
    print("❌ فشل تسجيل الدخول:", r.text)
    return False

def get_inbounds():
    r = session.get(f"{BASE_URL}/panel/api/inbounds/list", verify=False, timeout=10)
    if r.ok:
        return r.json().get("obj", [])
    return []

def delete_expired_clients():
    now_ms = int(datetime.now().timestamp() * 1000)
    inbounds = get_inbounds()
    total_deleted = 0

    for inbound in inbounds:
        inbound_id = inbound["id"]
        remark = inbound.get("remark", f"inbound-{inbound_id}")
        clients = inbound.get("clientStats", [])

        for client in clients:
            email = client.get("email", "")
            expiry = client.get("expiryTime", 0)

            # منتهي إذا expiryTime أقل من الوقت الحالي وليس 0
            if expiry != 0 and expiry < now_ms:
                # حذف الكلايانت
                r = session.post(
                    f"{BASE_URL}/panel/api/inbounds/{inbound_id}/delClient/{email}",
                    verify=False, timeout=10
                )
                if r.ok and r.json().get("success"):
                    exp_date = datetime.fromtimestamp(expiry/1000).strftime("%Y-%m-%d")
                    print(f"🗑️  حُذف: {email} | {remark} | انتهى: {exp_date}")
                    total_deleted += 1
                else:
                    print(f"⚠️  فشل حذف: {email} | {r.text}")

    print(f"\n✅ انتهى — تم حذف {total_deleted} كلايانت منتهي")

if __name__ == "__main__":
    print(f"🕐 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("─" * 40)
    if login():
        delete_expired_clients()
